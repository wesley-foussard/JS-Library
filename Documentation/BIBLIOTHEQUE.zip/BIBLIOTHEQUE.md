**EDITION** (<ins>code_edition</ins>, nom, site)<br>
**LIVRE** (<ins>code_user</ins>, titre, auteur, numéro, genre, pages, couverture, date publication, edition, ISBN, _#code_user.1_, _#code_edition_)<br>
**ORGANISE** (<ins>_#code_user_</ins>, <ins>_#code_user.1_</ins>)<br>
**UTILISATEUR** (<ins>code_user</ins>, pseudo, mdp)