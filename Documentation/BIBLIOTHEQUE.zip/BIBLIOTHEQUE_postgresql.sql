CREATE DATABASE BIBLIOTHEQUE;
\c BIBLIOTHEQUE;

CREATE TABLE EDITION (
  code_edition VARCHAR(42),
  nom VARCHAR(42),
  site VARCHAR(42),
  PRIMARY KEY (code_edition)
);

CREATE TABLE LIVRE (
  code_user VARCHAR(42),
  titre VARCHAR(42),
  auteur VARCHAR(42),
  numéro VARCHAR(42),
  genre VARCHAR(42),
  pages VARCHAR(42),
  couverture VARCHAR(42),
  date_publication VARCHAR(42),
  edition VARCHAR(42),
  isbn VARCHAR(42),
  code_user_1 VARCHAR(42),
  code_edition VARCHAR(42),
  PRIMARY KEY (code_user)
);

CREATE TABLE ORGANISE (
  code_user VARCHAR(42),
  code_user_1 VARCHAR(42),
  PRIMARY KEY (code_user, code_user_1)
);

CREATE TABLE UTILISATEUR (
  code_user VARCHAR(42),
  pseudo VARCHAR(42),
  mdp VARCHAR(42),
  PRIMARY KEY (code_user)
);

ALTER TABLE LIVRE ADD FOREIGN KEY (code_edition) REFERENCES EDITION (code_edition);
ALTER TABLE LIVRE ADD FOREIGN KEY (code_user_1) REFERENCES UTILISATEUR (code_user);
ALTER TABLE ORGANISE ADD FOREIGN KEY (code_user_1) REFERENCES LIVRE (code_user);
ALTER TABLE ORGANISE ADD FOREIGN KEY (code_user) REFERENCES UTILISATEUR (code_user);